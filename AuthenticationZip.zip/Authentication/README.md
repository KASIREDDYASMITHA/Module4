# Mini Auth System

A simple user authentication API built with Node.js, Express.js, and Supabase (PostgreSQL).

## 🚀 Features
- User Signup with hashed password (bcrypt)
- Fetch user profile (without exposing password)
- Supabase as database
- Modular project structure


